#@title Input protein sequence(s), then hit `Runtime` -> `Run all`
from google.colab import files
import os.path
import re
import hashlib
import random
import sys

from colabfold.download import download_alphafold_params, default_data_dir
from colabfold.utils import setup_logging
from colabfold.batch import get_queries, run, set_model_type

from colabfold.colabfold import plot_protein
from pathlib import Path
import matplotlib.pyplot as plt

import warnings
warnings.simplefilter(action='ignore', category=FutureWarning)


def fastaParser(string):
  fasta = open(string, "r")
  sequence = ""
  for line in fasta.readlines():
    if line[0] != ">":
      if line[-1:] == "\n":
        sequence+=line[:-1]
      else :
        sequence+=line
  return sequence


def add_hash(x,y):
  return x+"_"+hashlib.sha1(y.encode()).hexdigest()[:5]

query_sequence =fastaParser(sys.argv[1]) #@param {type:"string"}
#@markdown  - Use `:` to specify inter-protein chainbreaks for **modeling complexes** (supports homo- and hetro-oligomers). For example **PI...SK:PI...SK** for a homodimer

query_sequence = "".join(query_sequence.split())
jobname = 'test'
basejobname = "".join(jobname.split())
basejobname = re.sub(r'\W+', '', basejobname)
jobname = add_hash(basejobname, query_sequence)
while os.path.isfile(f"{jobname}.csv"):
  jobname = add_hash(basejobname, ''.join(random.sample(query_sequence,len(query_sequence))))

with open(f"{jobname}.csv", "w") as text_file:
    text_file.write(f"id,sequence\n{jobname},{query_sequence}")

queries_path=f"{jobname}.csv"

a3m_file = f"{jobname}.a3m"


result_dir="./results"
if 'logging_setup' not in globals():
    setup_logging(Path(".").joinpath("log.txt"))
    logging_setup = True

queries, is_complex = get_queries(queries_path)
model_type = set_model_type(is_complex, "auto")#["auto", "AlphaFold2-ptm", "AlphaFold2-multimer-v1", "AlphaFold2-multimer-v2"]
download_alphafold_params(model_type, Path("."))


print("preparation\n")
run(
    queries=queries,
    result_dir=result_dir,
    use_templates=False,
    custom_template_path=None,
    use_amber=False,#@param {type:"boolean"}
    msa_mode="MMseqs2 (UniRef+Environmental)", #@param ["MMseqs2 (UniRef+Environmental)", "MMseqs2 (UniRef only)","single_sequence","custom"]  
    model_type=model_type, 
    num_models=1,
    num_recycles=3, #@param [1,3,6,12,24,48] {type:"raw"}
    model_order=[1],
    is_complex=is_complex,
    data_dir=Path("."),
    keep_existing_results=False,
    recompile_padding=1.0,
    rank_by="auto",
    pair_mode="unpaired+paired", #@param ["unpaired+paired","paired","unpaired"] {type:"string"}
    stop_at_score=float(100),

)

print("run")