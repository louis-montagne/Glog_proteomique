# GLOG
Avant de pouvoir faire tourner toute les fonctionnalité du site il faut reinstaller l'environnement conda trop lourd pour être transmis par github,
pour cela il va falloir le recréer à l'aide du fichier yml, pour cela il vous faudra avoir conda installer sur votre machine, vous mettre sur le repertoir du fichier yml et taper la commande suivante:
    conda env create -f condafold.yml

Ensuite avant de pouvoir lancer la partie prédiction avec alphafold, il vous faudra d'abord avoir NodeJs installé sur votre machine et ensuite vous placer dans le répertoire Server.js et taper la commande suivante:
    node Server.js

Ensuite lors de vos première prédiction l'algorithme alphafold aura besoin de télécharger les modèle, ce qui peut prendre quelque minutes.