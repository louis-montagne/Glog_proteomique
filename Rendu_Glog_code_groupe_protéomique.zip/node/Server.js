const express = require("express");
const multer = require('multer');
const https = require('https');
const fs = require('fs')
var path = require('path');
const app = express();

app.use(express.static(path.join(__dirname, '/')));

const options = {
  key: fs.readFileSync('key.pem'),
  cert: fs.readFileSync('cert.pem')
};

https.createServer(options, app ).listen(2000, function () {
  console.log("Server is running on port 2000! Go to https://localhost:2000/");
});

const storage = multer.diskStorage({
  destination: function (req, file, callback) {
    callback(null, './uploads');
  },
  filename: function (req, file, callback) {
    callback(null, file.originalname);
  }
});
const upload = multer({ storage: storage }).single('myfile');

app.get('/', function (req, res) {
  res.sendFile(__dirname + "/index.html");
});

app.post('/upload', function (req, res) {
  upload(req, res, function (err) {
    if (err) {
      return res.end("Error uploading file.");
    }
    res.end("File is uploaded successfully!");
  });
});

app.post('/predict', function (req, res) {
  const directoryPath = path.join(__dirname, 'uploads');
  const { spawn } = require('child_process');
  fs.readdir(directoryPath, function (err, files) {
    //handling error
    if (err) {
      return console.log('Unable to scan directory: ' + err);
    }
    //listing all files using forEach
    files.forEach(function (file) {
      const python = spawn('/home/jim/Documents/Glog/Glog-prot/node/condafold/bin/python3.8', ['./pythonfold/fold.py', 'uploads/'+ file, `test`],);
      python.stdout.on('end', function () {
        console.log(`File used : ${file}, jobname : test`);
        fs.unlink(path.join(directoryPath, file), (err) => {
          if (err) throw err;
          res.end("File ready to download !")
        });

      });

    });

  });
});

app.get('/download', function (req, res) {
  const directoryPath2 = path.join(__dirname, 'results');
  fs.readdir(directoryPath2, function (err, files) {
    files.forEach(function (file) {
      if (file.endsWith(".pdb")) {
        var filePath = "results/" + file;
        var fileName = `predict.pdb`;
        res.download(filePath, fileName, function (err) {
          if (err) { console.log(err); }
          else {
            fs.unlinkSync(path.join(directoryPath2, file), (err) => {
              if (err) throw err;
            });
          }
        });
        console.log(`File dowloaded : ${filePath}, name : test${fileName}`);
      }
      else {
        var directory = "results/" + file;
        fs.rm(directory, { recursive: true }, err => {
          if (err) throw err;
        });
      }
    });
  });
});
